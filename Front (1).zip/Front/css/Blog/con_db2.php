<?php 
$connect=mysqli_connect('localhost','id21917744_4443361_asphallthasa','AsphalltKsa19$23')or die  (mysqli_error());

mysqli_select_db($connect,'id21917744_4443361_asphallthasa');
?>